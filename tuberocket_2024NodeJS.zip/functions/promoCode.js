const axios = require('axios');
async function promoCode(token){
    const headers = {
        'token': token,
        'Host': 'tuberocket.app:3000',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
        'User-Agent': 'okhttp/3.12.0'
    }
    const d = {"bind_code": "47tnma"}
    const {data} = await axios.put("http://tuberocket.app:3000/api/share-code", d, {headers});
    return data;
}

module.exports = { promoCode };