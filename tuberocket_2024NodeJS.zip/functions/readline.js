const { clear } = require('console');
const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
    shell: true
});
async function input(question) {
    return new Promise((resolve, reject) => {
        rl.question(question, (data) => {
            resolve(data);
        });
    });
}
const clearTerminal = () => {
    rl.output.write('\x1B[2J\x1B[3J\x1B[H');
};

module.exports = { input, clearTerminal };