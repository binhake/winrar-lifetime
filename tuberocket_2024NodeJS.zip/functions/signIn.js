const axios = require('axios');
const { versionCheck } = require('./versionCheck');
async function signIn(tokenapp, android, device, locale, deviceToken, sensors){
    const headers = {
        "token": tokenapp,
        "versionCode": (await versionCheck())['result']['version_android'].toString(),
        "android": android,
        "device": device,
        "locale": locale,
        "deviceToken": deviceToken,
        "sensors": sensors,
        "Content-Length": "0",
        "Host": "tuberocket.app:3000",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/3.12.0"
    };
    const { data } = await axios.post("http://tuberocket.app:3000/api/signIn", null, { headers });
    return data;
}

module.exports = { signIn };