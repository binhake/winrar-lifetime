const axios = require('axios');
async function onLoadFailed(token, id, playCount, playSecond, boost){
    const d = {
        "id": id,
        "playCount": playCount,
        "playSecond": playSecond,
        "boost": boost,
        "status": "onLoadFailed"
    };
    const headers = {
        "token": token,
        "height": "0.0",
        // "Content-Type": "application/json; charset=UTF-8",
        // "Content-Length": d.length.toString(),
        "Host": "tuberocket.app:3000",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/3.12.0"
    };
    const {data} = await axios.put("http://tuberocket.app:3000/api/video", d, {headers});
    return data;
}

module.exports = { onLoadFailed };