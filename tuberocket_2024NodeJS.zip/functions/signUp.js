const axios = require('axios');
async function signUp(){
    const headers = {
        // "Content-Type": "application/json; charset=UTF-8",
        "Host": "tuberocket.app:3000",
        "Connection": "Keep-Alive",
        "Content-Length": "1207",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/3.12.0"
    };
    const d = {
        "googleToken": googleToken,
        "googleId": googleId
    };
    const {data} = await axios.post("http://tuberocket.app:3000/api/signUp", d, {headers});
    return data;
}

module.exports = { signUp };