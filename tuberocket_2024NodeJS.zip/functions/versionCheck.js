const axios = require('axios');
async function versionCheck(){
    const headers = {
        "Host": "tuberocket.app:3000",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/3.12.0",
    };
    const { data } = await axios.get("http://tuberocket.app:3000/api/version-check", {headers});
    return data;
}

module.exports = { versionCheck };