const { parentPort } = require('worker_threads');

async function updateTitle() {
    let internet = false;
    process.stdout.write('\x1b[2K');
    while(!internet){
        process.stdout.write(`Mất kết nối mạng. Đang chờ kết nối lại...\r`);
        try {
            await axios.get("https://google.com");
            internet = true;
            for (let i=3; i>=0; i--){
                process.stdout.write(`Đã có kết nối mạng trở lại. Tiếp tục chạy sau ${i} giây...\r`);
                await sleep(1000);
            }
            break;
        } catch (err){
            if (err.request || err.response){
                continue;
            }
        }
    }




    parentPort.postMessage(); // Send message to main.js in this line function
}

updateTitle();