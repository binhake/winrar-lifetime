const axios = require('axios');
async function shareCodeCoin(token){
    const headers = {
        "token": token,
        "Content-Length": "0",
        "Host": "tuberocket.app:3000",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/3.12.0"
    };
    const {data} = await axios.put("http://tuberocket.app:3000/api/share-code-coin", null, {headers});
    return data;
}

module.exports = { shareCodeCoin };