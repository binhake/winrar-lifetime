async function randomColor() {
    // const colors = {
    //     reset: "\x1b[0m",
    //     bright: "\x1b[1m",
    //     dim: "\x1b[2m",
    //     underscore: "\x1b[4m",
    //     blink: "\x1b[5m",
    //     reverse: "\x1b[7m",
    //     hidden: "\x1b[8m",
    //     // fgBlack: "\x1b[30m",
    //     fgRed: "\x1b[31m",
    //     fgGreen: "\x1b[32m",
    //     fgYellow: "\x1b[33m",
    //     fgBlue: "\x1b[34m",
    //     fgMagenta: "\x1b[35m",
    //     fgCyan: "\x1b[36m",
    //     fgWhite: "\x1b[37m",
    //     bgBlack: "\x1b[40m",
    //     bgRed: "\x1b[41m",
    //     bgGreen: "\x1b[42m",
    //     bgYellow: "\x1b[43m",
    //     bgBlue: "\x1b[44m",
    //     bgMagenta: "\x1b[45m",
    //     bgCyan: "\x1b[46m",
    //     bgWhite: "\x1b[47m"
    // };
    const colors = {
        "Eastern Blue Water Leaf": "\x1b[38;2;24;165;167m",
        "Blue Zodiac Lavender": "\x1b[38;2;221;131;224m",
        "Niagara Sleptic": "\x1b[38;2;203;231;227m",
        "Blue and Light Blue": "\x1b[38;2;158;186;243m",
        "Light Pink": "\x1b[38;2;239;136;187m",
        "Dark Orange (maybe)": "\x1b[38;2;255;179;48m",
        "Light Yellow": "\x1b[38;2;255;252;206m",
        "LIGHT ORANGE": "\x1b[38;2;255;205;178m",
        "RED AND PINK": "\x1b[38;2;250;166;255m",
        "DA6085": "\x1b[38;2;218;96;133m",
        "D7EDE1": "\x1b[38;2;215;237;225m",
        "FD986A": "\x1b[38;2;253;152;106m",
        "FFC9C9": "\x1b[38;2;255;201;201m",
        "FD80A8": "\x1b[38;2;253;128;168m",
        "FCCF42": "\x1b[38;2;252;207;66m",
        "A0EACF": "\x1b[38;2;160;234;207m",
        "C9D3EC": "\x1b[38;2;201;211;236m",
        "CBBAF1": "\x1b[38;2;203;186;241m",
        "F9C929": "\x1b[38;2;249;201;41m",
        "EEF4D2": "\x1b[38;2;238;244;210m",
        "FB8883": "\x1b[38;2;251;136;131m",
        "E5CDC3": "\x1b[38;2;229;205;195m",
        "38A2D6": "\x1b[38;2;56;162;214m",
        "CAB9F1": "\x1b[38;2;202;185;241m",
        "FD9869": "\x1b[38;2;253;152;105m",
        "FEC9C9": "\x1b[38;2;254;201;201m",
        "38A2D7": "\x1b[38;2;56;162;215m",
        "C8D3EB": "\x1b[38;2;200;211;235m"
    };
      
    const colorNames = Object.keys(colors); // .filter(color => color.startsWith('fg'));
    const randomIndex = Math.floor(Math.random() * colorNames.length);
    return colors[colorNames[randomIndex]];
}

module.exports = { randomColor };