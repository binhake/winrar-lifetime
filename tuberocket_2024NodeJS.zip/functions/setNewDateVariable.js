async function setNewDateVariable(){
    return new Date();
}

module.exports = { setNewDateVariable };