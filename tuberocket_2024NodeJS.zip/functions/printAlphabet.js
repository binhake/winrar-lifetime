const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
async function printAlphabet(text){
    const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ ';
    let temp = '';
    for (let ch of text) {
        for (let i of alphabet) {
            if (i === ch || ch === ' ') {
                await sleep(1);
                process.stdout.write(temp + i + '\r');
                temp += ch;
                break;
            } else {
                await sleep(1);
                process.stdout.write(temp + i + '\r');
            }
        }
    }
    console.log(text + "\n");
}

module.exports = { printAlphabet };