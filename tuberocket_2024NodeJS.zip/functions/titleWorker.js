const { parentPort } = require('worker_threads');

async function updateTitle() {
    let startTime = new Date();
    const _version = "3.0.0";

    while (true) {
        const elapsedTime = new Date(new Date() - startTime);
        const days = (elapsedTime.getUTCDate() - 1).toString().padStart(2, '0');
        const hours = elapsedTime.getUTCHours().toString().padStart(2, '0');
        const minutes = elapsedTime.getUTCMinutes().toString().padStart(2, '0');
        const seconds = elapsedTime.getUTCSeconds().toString().padStart(2, '0');
        
        parentPort.postMessage(`SCRIPT AUTO TUBEROCKET by NGUYỄN TRỌNG BÌNH v${_version} >> SCRIPT: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(0)} MB RAM USED | ${days}:${hours}:${minutes}:${seconds}`);

        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

updateTitle();
