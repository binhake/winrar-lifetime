const exec = require('./exec').exec;
const printAlphabet = require('./printAlphabet').printAlphabet;
const input = require('./readline').input;
const clearTerminal = require('./readline').clearTerminal;
const jwtDecode = require('./jwtDecode').jwtDecode;
const check_key = require('./check_key').check_key;
const generateJWT = require('./generateJWT').generateJWT;
const readDirectoryAsync = require("./readDirectoryAsync").readDirectoryAsync
const signIn = require('./signIn').signIn;
const member = require('./member').member;
const os = require('os');
const fs = require('fs');
const Table = require('cli-table')
const path = require('path');
const gradient = require('gradient-string');
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let key, pass;
let tokenapp, android, device, locale, deviceToken, sensors;
let signInFunctionRequestCount = 0;
let dem;
async function newMinor(){
    try {
        // Python code: os.system('cls' if os.name == 'nt' else 'clear')
        // await exec('cls');
        // os.platform() == "win32" ? await exec('cls') : await exec('clear');
        console.log(`------------------------------------`);
        // await printAlphabet(`I'm Binhake!`);
        await sleep(1000);
        try {
            key = await input(`Nhập Key: `);
            pass = await input(`Nhập mật khẩu: `);
            dem = 0;
            while(dem < 4){
                let token = await jwtDecode(await check_key("verifyCertificate", key, pass), await generateJWT());
                if (token != null){
                    if (token.data.status == "success"){
                        if (token.data.type == "Premium"){
                            console.log(">>> "+token.data.message+"\n");
                            break;
                        } else {
                            console.log(">>> Key hợp lệ!\n");
                            break;
                        }
                    } else {
                        console.log(">> Key không hợp lệ!\n");
                        process.exit();
                    }
                } else {
                    if (dem == 3){
                        console.log("Có lỗi trong khi phân tích kết quả từ Server!");
                        process.exit(1);
                    } else {
                        dem++;
                        continue;
                    }
                }
            }
        } catch (err){
            console.log("Có lỗi trong module kiểm tra khóa truy cập!");
            console.log(err);
            process.exit(1);
        }
        let configImportStatus = 0;
        let jsonFiles = [];
        let tokenListFile = [], tokenListTypeFile = [];
        let option;
        let jsonData;
        let wantAutoDetect = true;
        let wantToTab = false;
        while(configImportStatus === 0){
            if (wantAutoDetect){
                await readDirectoryAsync(path.resolve(__dirname, '..'), jsonFiles, jsonData, tokenListFile, tokenListTypeFile);

                // Ở bước AutoDetect này là đã lấy được list file .json có token hợp lệ nè (cả config.json lẫn request.json)
                // Lưu trong biến tokenListFile
                // Giờ đi xử lý xem File Token nào còn xài được nè
                // Hướng xử lý sẽ là:
                // - Gọi func signIn và lấy retCode để kiểm tra, nếu còn dùng được thì lấy luôn email. Không thì bỏ qua
                // - Lưu toàn bộ email đã lấy được vào 1 mảng dạng: {[tên_file]:"abc@gmail.com"}

                let emailTuberocketKeysList = [], emailTuberocketValuesList = [], emailTuberocketTypeList = [];
                for(let i = 0; i < tokenListFile.length; i++){
                    let info;
                    try {
                        jsonData = JSON.parse(fs.readFileSync(tokenListFile[i], 'utf8'));
                    } catch (err){
                        console.log(`File ${jsonFiles[i]} không phải là JSON hợp lệ!`)
                        process.exit();
                    }
                    if (tokenListTypeFile[i] == "config.json"){
                        try {
                            info = (await signIn(jsonData.tokenapp, jsonData.android, jsonData.device, jsonData.locale, jsonData.deviceToken, jsonData.sensors));
                        } catch(err){
                            signInFunctionRequestCount++;
                            i--;
                            continue;
                        }
                        if (info['retCode'] == 0){
                            try {
                                info = (await member(info['result']['token'])).result.email;
                            } catch(err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            emailTuberocketKeysList.push(tokenListFile[i]);
                            emailTuberocketValuesList.push(info);
                            emailTuberocketTypeList.push("config.json");
                        }
                    } else if (tokenListTypeFile[i] == "request.json"){
                        try {
                            info = (await signIn(jsonData.headers.token, jsonData.headers.android, jsonData.headers.device, jsonData.headers.locale, jsonData.headers.deviceToken, jsonData.headers.sensors));
                        } catch (err){
                            signInFunctionRequestCount++;
                            i--;
                            continue;
                        }
                        if (info['retCode'] == 0){
                            try {
                                info = (await member(info['result']['token'])).result.email;
                            } catch(err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            emailTuberocketKeysList.push(tokenListFile[i]);
                            emailTuberocketValuesList.push(info);
                            emailTuberocketTypeList.push("request.json");
                        }
                    } else {
                        console.log("Xảy ra lỗi trong quá trình tự động nhận dạng File Token!");
                        process.exit(1);
                    }
                }

                // Nếu không có File Token nào còn sử dụng được thì cho lặp lại while để chạy xuống điều kiện buộc người dùng nhập dirname của File Config
                if (emailTuberocketKeysList.length == 0){
                    console.log(">>> Không phát hiện File Token hợp lệ nào trên cùng đường dẫn!");
                    wantAutoDetect = false;
                    wantToTab = true;
                    continue;
                }

                // Gòi ở đây chúng ta đã có mảng emailTuberocketKeysList và emailTuberocketValuesList có list những file token xài được rồi nè. Dạng tên_file - email
                // Giờ đem hỏi user xem có muốn dùng không là oke nè
                console.log(`>>> Phát hiện các File Token sau trên cùng đường dẫn:`);
                dem = 1;
                // for (let i = 0; i < emailTuberocketKeysList.length; i++){
                //     console.log(` ${dem}. ${emailTuberocketKeysList[i]}: ${emailTuberocketValuesList[i]}`);
                //     dem++;
                // }
                const table = new Table({
                    head: [gradient('cyan', 'cyan')("STT"), gradient('cyan', 'violet')("Tên File"), gradient('violet', 'violet')("Email")],
                    colAligns: ['middle', 'middle', 'middle']
                });
                const data = [];
                for (let i = 0; i < Math.max(emailTuberocketKeysList.length, emailTuberocketValuesList.length); i++) {
                    const subArray = [];
                    let temp = "";
                    subArray.push(dem++);
                    if (i < emailTuberocketKeysList.length) {
                        if (emailTuberocketKeysList[i].length > 12){
                            subArray.push(emailTuberocketKeysList[i].substring(0, 12) + "...");
                        } else {
                            subArray.push(emailTuberocketKeysList[i]);
                        }
                    }
                    if (i < emailTuberocketValuesList.length) {
                        if (emailTuberocketValuesList[i].length > 22){
                            subArray.push(emailTuberocketValuesList[i].substring(0,22) + "...");
                        } else {
                            subArray.push(emailTuberocketValuesList[i]);
                        }
                    }
                    data.push(subArray);
                }
                table.push(...data);
                console.log(table.toString() + "\n");
                // console.log();
                await sleep(500);
                option = await input("Bạn muốn dùng Token nào không? (Nhập STT để chọn hoặc để trống để từ chối): ");
                if (option > 0 && option <= dem - 1){ // Nếu người dùng chọn File thì lấy token tương ứng nè
                    option = Number(option)-1;
                    jsonData = JSON.parse(fs.readFileSync(emailTuberocketKeysList[option], 'utf8'));
                    if (emailTuberocketTypeList[option] == "config.json"){
                        ({ tokenapp, android, device, locale, deviceToken, sensors } = jsonData);
                        configImportStatus = 1;
                        console.log(">>> Import Config thành công!\n");
                        break;
                    } else if (emailTuberocketTypeList[option] == "request.json"){
                        ({ token: tokenapp, android, device, locale, deviceToken, sensors } = jsonData.headers);
                        configImportStatus = 1;
                        console.log(">>> Import Config thành công!\n");
                        break;
                    } else {
                        console.log("Xảy ra lỗi trong quá trình Import File Config!");
                        process.exit(1);
                    }
                } else { // Nếu người dùng từ chối thì cho vòng lặp tiếp theo là lấy user keyboard nè
                    wantAutoDetect = false;
                    console.log(">>> Bạn đã từ chối dùng File Token có sẵn.\n");
                    continue;
                }
            } else {
                if (wantToTab){
                    jsonData = await input("    Nhập Đường dẫn File Config/File request.json/Object Token Tuberocket đã lấy: ");
                } else {
                    jsonData = await input("Nhập Đường dẫn File Config/File request.json/Object Token Tuberocket đã lấy: ");
                }
                
                let info;
                try {
                    if (fs.existsSync(jsonData) == true){ // Detect __dirname of config.json/request.json
                        jsonData = JSON.parse(fs.readFileSync(jsonData, 'utf8'));
                        if (jsonData.hasOwnProperty("tokenapp") && typeof jsonData.tokenapp === "string" && jsonData.tokenapp.length === 32 &&
                        jsonData.hasOwnProperty("android") && typeof jsonData.android === "string" && jsonData.android.length === 2 &&
                        jsonData.hasOwnProperty("device") && typeof jsonData.device === "string" &&
                        jsonData.hasOwnProperty("locale") && typeof jsonData.locale === "string" && jsonData.locale.length === 2 &&
                        jsonData.hasOwnProperty("deviceToken") && typeof jsonData.deviceToken === "string" &&
                        jsonData.hasOwnProperty("sensors")){
                            try {
                                info = (await signIn(jsonData.tokenapp, jsonData.android, jsonData.device, jsonData.locale, jsonData.deviceToken, jsonData.sensors));
                            } catch(err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            if (info['retCode'] == 0){
                                ({ tokenapp, android, device, locale, deviceToken, sensors } = jsonData);
                                configImportStatus = 1;
                                console.log(">>> Import Config thành công!\n");
                                break;
                            }
                        } else if (jsonData.headers &&
                        jsonData.headers.token && (jsonData.headers.token).length == 32 &&
                        jsonData.headers.android && (jsonData.headers.android).length == 2 &&
                        jsonData.headers.device &&
                        jsonData.headers.locale && (jsonData.headers.locale).length == 2 &&
                        jsonData.headers.deviceToken &&
                        jsonData.headers.sensors){
                            try {
                                info = (await signIn(jsonData.headers.token, jsonData.headers.android, jsonData.headers.device, jsonData.headers.locale, jsonData.headers.deviceToken, jsonData.headers.sensors));
                            } catch(err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            if (info['retCode'] == 0){
                                ({ token: tokenapp, android, device, locale, deviceToken, sensors } = jsonData.headers);
                                configImportStatus = 1;
                                console.log(">>> Import Config thành công!\n");
                                break;
                            } else {
                                console.log("Token trong Config không đúng hoặc đã hết hạn!");
                                continue;
                            }
                        }
                    } else if (JSON.parse(jsonData) == true) { // Detect config.json/request.json object from user keyboard
                        jsonData = JSON.parse(jsonData);
                        if (jsonData.hasOwnProperty("tokenapp") && (jsonData.tokenapp).length == 32 && typeof(jsonData.tokenapp) == "string" &&
                        jsonData.hasOwnProperty("android") && (jsonData.android).length == 2 && typeof(jsonData.android) == "string" &&
                        jsonData.hasOwnProperty("device") && typeof(jsonData.device) == "string" &&
                        jsonData.hasOwnProperty("locale") && (jsonData.locale).length == 2 && typeof(jsonData.locale) == "string" &&
                        jsonData.hasOwnProperty("deviceToken") && typeof(jsonData.deviceToken) == "string" &&
                        jsonData.hasOwnProperty("sensors")){ // Detect config.json object
                            try {
                                info = (await signIn(jsonData.token, jsonData.android, jsonData.device, jsonData.locale, jsonData.deviceToken, jsonData.sensors));
                            } catch (err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            if (info['retCode'] == 0){
                                ({ tokenapp, android, device, locale, deviceToken, sensors } = jsonData);
                                configImportStatus = 1;
                                console.log(">>> Import Config thành công!\n");
                                break;
                            } else {
                                console.log('Token không sử dụng được!');
                                process.exit(1);
                            }
                        } else if (jsonData.headers.token && (jsonData.headers.token).length == 32 &&
                        jsonData.headers.android && (jsonData.headers.android).length == 2 &&
                        jsonData.headers.device &&
                        jsonData.headers.locale && (jsonData.headers.locale).length == 2 &&
                        jsonData.headers.deviceToken &&
                        jsonData.headers.sensors){ // Detect request.json object
                            try {
                                info = (await signIn(jsonData.headers.token, jsonData.headers.android, jsonData.headers.device, jsonData.headers.locale, jsonData.headers.deviceToken, jsonData.headers.sensors));
                            } catch (err){
                                signInFunctionRequestCount++;
                                i--;
                                continue;
                            }
                            if (info['retCode'] == 0){
                                ({ token: tokenapp, android, device, locale, deviceToken, sensors } = jsonData.headers);
                                configImportStatus = 1;
                                console.log(">>> Import Config thành công!\n");
                                break;
                            }
                        } else {
                            console.log('Không nhận dạng được Format đầu vào!');
                            process.exit(1);
                        }
                    } else {
                        console.log("Dữ liệu đầu vào không hợp lệ!");
                        process.exit(1);
                    }
                } catch (err){
                    console.log("Dữ liệu nhập vào không hợp lệ!");
                    process.exit(1);
                }
            }
        }
        demVideo = await input('Bạn có muốn đếm các video bị Failed trong khi xem không? (Nhập y/n hoặc để trống để mặc định là không đếm): ');
        if (demVideo == "y"){
            demVideo = true;
            console.log(">>> Đếm video Failed: Có!\n");
        } else {
            demVideo = false;
            console.log(">>> Đếm video Failed: Không!\n");
        }
    } catch (err){
        console.log("Xảy ra ngoại lệ trong khi thực thi chương trình!");
        process.exit(1);
    }
}
function returnKey(){
    return key;
}
function returnPass(){
    return pass;
}
function returnTokenapp(){
    return tokenapp;
}
function returnAndroid(){
    return android;
}
function returnDevice(){
    return device;
}
function returnLocale(){
    return locale;
}
function returnDeviceToken(){
    return deviceToken;
}
function returnSensors(){
    return sensors;
}
function returnSignInFunctionRequestCount(){
    return signInFunctionRequestCount;
}

module.exports = { newMinor, returnKey, returnPass, returnTokenapp, returnAndroid, returnDevice, returnLocale, returnDeviceToken, returnSensors, returnSignInFunctionRequestCount };