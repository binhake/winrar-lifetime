const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const aaaa = {
    versionCheck: 'e11ffe459ef46cb5a58f59664ca9b1d1',
    signIn: '21e042899b5f1767910a7f8c9a9a3faa',
    member: 'cbb45594a4f2087adb8a964db15513e6',
    shareCodeCoin: '18cfee60b97ecda3e0e647da61579651',
    getVideo: '6d836b6fcd3b531c7bb1599aa951819a',
    claim: '70c2898f1f59b7ee287b780f8612b9c5',
    onLoadFailed: '3edac15fc238ffad6bd5f969c8eeabb0',
    promoCode: 'f6706eb986334a3714e04d8a60a85d67',
    generateJWT: '0fed32d9fcf4fd6cd1e617f5415141b7',
    jwtDecode: '1a886131f0531985faaf41ab1ded2254',
    check_key: '9f81cba5f351615d5476bc518cc6d511',
    getIPv4: '7a2494dcbd034166088e350b02f4f13b',
    logExport: 'f75f6eba57b011ee2d6880976a3d15e9',
    getTime: '286ef43dbff1b43f8f6bebb7c14f4492',
    minor: 'bac2d3994556d2cf42fe9e215b3a8c6a',
    readDirectoryAsync: 'b429314d2f3bf2ae608fff4cf13ab065',
    randomColor: 'b814c92c9c0886033815a4406daeca3d',
    getYoutubeInfo: '09fe1fad87faff65a8a15534511a520b'
};

async function checkFileIntegrity(filePath, initialMD5) {
    const fileMD5 = crypto.createHash('md5').update(fs.readFileSync(filePath)).digest('hex');
    return fileMD5 === initialMD5;
}

async function checkAllFilesIntegrity(fileObj, baseDir) {
    let results = {};
    for (const [fileName, initialMD5] of Object.entries(fileObj)) {
        try {
            const isIntact = await checkFileIntegrity(path.join(baseDir, fileName+'.js'), initialMD5);
            results[fileName] = isIntact ? 'Intact' : 'Corrupted, MD5: ' + initialMD5;
        } catch (error) {
            results[fileName] = `Error: ${error.message}`;
        }
    }
    return results;
}

// Đường dẫn tới thư mục chứa các file
const baseDir = './functions/'; // Thay thế bằng đường dẫn thực tế

// Kiểm tra tất cả các file và in kết quả
async function main(){
    await checkAllFilesIntegrity(aaaa, baseDir).then(results => {
        console.log(results);
    }).catch(error => {
        console.error('Error checking file integrity:', error);
    });
    console.log("Done!");
}
main();
async function checkFileIntegrity(filePath, initialMD5) {
    const fileMD5 = crypto.createHash('md5').update(fs.readFileSync(filePath)).digest('hex');
    return fileMD5 === initialMD5;
}
