async function argvProcess(actionIndex){
    const args = process.argv.slice(2);
    actionIndex = args.indexOf('--action');
    if (actionIndex !== -1 && actionIndex + 1 < args.length) {
        return args[actionIndex + 1];
    } else {
        // console.error('Arguments not specified or invalid.');
        return null;
    }
}

module.exports = { argvProcess };