// retCode 0    : Success
// retCode 4    : Token Invalid
// retCode 100  : Missing parameter: (value required)
// retCode 400  : Queue Full
// retCode 401  : Video In Quere
// retCode 402  : Video Not Found (claim() or getVideo())
// retCode 407  : ...
// retCode 427  : ...

// statusCode 429   : Too many requests, please try again later.

process.env.TZ  = 'Asia/Ho_Chi_Minh';
const _             = global['_']           = "binhake";
const _version      = global['_version']    = "3.0.0";
const normalError   = global['normalError'] = "Xảy ra ngoại lệ trong khi thực thi chương trình!";

const youtube_api_key = "";
const googleId = "";
const googleToken = "";
// const tokenapp = "6dcf0d90618611ebb52031d4c3d6d09a";
// const android = "30";
// const device = "Xiaomi 21061119AG";
// const locale = "VN";
// const deviceToken = "f3oybaUGTtO2Rex8FU1T-p:APA91bFRaI26r4bGJonaB9AhniHysObHyeWmy8CES4I0lsnju16P0wzDO4E7Y3YbgkNOsh7o1nzJX1EhUNGjWF-PuBJvwNrvcFzkNZd70IpjozYukf-Nn5NAXjpYM0Ysm2NuWUbNplpd";
// const sensors = "{'accelerometer':{'maximumRange':78.453156,'name':'lis2hh12','power':0.001,'dataolution':0.0012,'type':1,'values':[0.82995003,9.10995,4.47195],'vendor':'ST','version':1},'gyroscope':{'maximumRange':34.906574,'name':'virtual_gyro','power':0.001,'dataolution':0.0011,'type':4,'values':[-8.25E-4,-8.25E-4,8.25E-4],'vendor':'ST','version':1},'light':{'maximumRange':65535.0,'name':'tmd2755_l','power':0.001,'dataolution':1.0,'type':5,'values':[0.0],'vendor':'AMS','version':1},'magnetometer':{'maximumRange':4911.994,'name':'akm09918','power':0.001,'dataolution':0.15,'type':2,'values':[43.2,-3.1875002,-2.2125],'vendor':'AKM','version':1},'proximity':{'maximumRange':5.0,'name':'tmd2755_p','power':0.001,'dataolution':1.0,'type':8,'values':[5.0,0.0,60.0],'vendor':'AMS','version':1}}";

let _titleClocking;
let axios, sleep, fs, moment, path, os, semver, gradient, crypto;
try {
    axios = require("axios");
    console.log(`Successfully loaded library node_modules/axios_${require('axios/package.json').version}`);
    os = require(`os`);
    console.log(`Successfully loaded library node_modules/os_${require('os/package.json').version}`);
    fs = require('fs');
    console.log(`Successfully loaded library node_modules/fs_${require('fs/package.json').version}`);
    path = require("path");
    console.log(`Successfully loaded library node_modules/path_${require('path/package.json').version}`);
    moment = require('moment');
    console.log(`Successfully loaded library node_modules/moment_${require('moment/package.json').version}`);
    semver = require('semver');
    console.log(`Successfully loaded library node_modules/semver_${require('semver/package.json').version}`);
    gradient = require('gradient-string');
    console.log(`Successfully loaded library node_modules/gradient-string_${require('gradient-string/package.json').version}`);
    crypto = require('crypto');
    console.log(`Successfully loaded library node_modules/crypto_${require('crypto/package.json').version}`);
    sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    console.log(`Successfully loaded library ENV/sleep_1.0.0`);
} catch (err){
    console.error("Phát hiện thiếu thư viện. Cài đặt hoặc bổ sung bằng cách sử dụng lệnh npm install hoặc npm i.");
    process.exit(1);
}

var log = [];
// let versionCheck, signIn, member, shareCodeCoin, getVideo, claim, onLoadFailed, promoCode;
// let generateJWT, jwtDecode;
// let check_key, getIPv4;
// let logExport, getTime, minor, readDirectoryAsync, randomColor; // CPULoad
// let getYoutubeInfo;
let key, pass;
const md5_module = {
    versionCheck: '9810355ff8fda5284d5a4f4a0da045bd',
    signIn: 'e88102497a166ae2b83fa00d8c0024a8',
    member: '183d2812f1cbd4f987deadf1c9006ce5',
    shareCodeCoin: '7995ee3446e4da2e09eecd81c12399b8',
    getVideo: '42a45d445bd110aae5cd6e5eb9c43f00',
    claim: '071a53abe138274cb0b3f3093f094a1c',
    onLoadFailed: 'ce448b6147ea5ac16e1d73439c0fdeb2',
    promoCode: '3d2fd165adaf2a8ddf19e51677cd2813',
    generateJWT: '7bd3ec89fce01a94e3dd7db537eb74fd',
    jwtDecode: 'bfdf8ba38d943e02dbc721c05954aab2',
    check_key: '8f23cf1ca8e5dee6377e1b22c933b59a',
    getIPv4: 'f03650475ec9adba1d0a8d3080f5eb89',
    logExport: 'f7cb5e2ba5f8fac9e81bbce2ee564b60',
    getTime: 'fe624fb005aabaf8d1bc757b04389ed8',
    minor: 'cd91e1e1ea258245dfbdace16e0f1b50',
    readDirectoryAsync: '3c0f7180f64584b2fef1ac357a76e2f1',
    randomColor: 'f1a17603086377df45a34dfd8e236e8d',
    getYoutubeInfo: 'f582be9952c739c452e90daadc5d53fd'
};
async function checkFileIntegrity(filePath, initialMD5) {
    const fileMD5 = crypto.createHash('md5').update(fs.readFileSync(filePath)).digest('hex');
    // console.log(`MD5 of ${filePath}: ${fileMD5}, Expected MD5: ${initialMD5}`);
    return fileMD5 === initialMD5;
}
async function checkMD5(md5_module){
    let filePath, fileName;
    let dirname = "functions";
    fileName = "versionCheck";
    try {
        filePath = path.join(dirname, `${fileName}.js`);
        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            versionCheck = require(path.join(__dirname, dirname, fileName)).versionCheck;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(err);
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }

    fileName = "signIn";
    try {
        filePath = path.join(dirname, `${fileName}.js`);
        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            signIn = require(path.join(__dirname, dirname, fileName)).signIn;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "member";
    try {
        filePath = path.join(dirname, `${fileName}.js`);
        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            member = require(path.join(__dirname, dirname, fileName)).member;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "shareCodeCoin";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            shareCodeCoin = require(path.join(__dirname, dirname, fileName)).shareCodeCoin;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "getVideo";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            getVideo = require(path.join(__dirname, dirname, fileName)).getVideo;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "claim";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            claim = require(path.join(__dirname, dirname, fileName)).claim;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "onLoadFailed";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            onLoadFailed = require(path.join(__dirname, dirname, fileName)).onLoadFailed;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "promoCode";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            promoCode = require(path.join(__dirname, dirname, fileName)).promoCode;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "generateJWT";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            generateJWT = require(path.join(__dirname, dirname, fileName)).generateJWT;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "jwtDecode";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            jwtDecode = require(path.join(__dirname, dirname, fileName)).jwtDecode;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "check_key";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            check_key = require(path.join(__dirname, dirname, fileName)).check_key;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "getIPv4";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            getIPv4 = require(path.join(__dirname, dirname, fileName)).getIPv4;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "logExport";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            logExport = require(path.join(__dirname, dirname, fileName)).logExport;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "getTime";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            getTime = require(path.join(__dirname, dirname, fileName)).getTime;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "minor";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            minor = require(path.join(__dirname, dirname, fileName)).newMinor;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "readDirectoryAsync";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            readDirectoryAsync = require(path.join(__dirname, dirname, fileName)).readDirectoryAsync;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
    
    fileName = "randomColor";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            randomColor = require(path.join(__dirname, dirname, fileName)).randomColor;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }

    fileName = "getYoutubeInfo";
    try {
        filePath = path.join(dirname, `${fileName}.js`);

        if (await checkFileIntegrity(filePath, md5_module[fileName])){
            getYoutubeInfo = require(path.join(__dirname, dirname, fileName)).getYoutubeInfo;
            console.log(`Successfully loaded module ${fileName}.js`);
        } else {
            console.log(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    } catch(err) {
        console.log(`Failed to load module ${fileName}.js`);
        process.exit(1);
    }
}
try {
    versionCheck = require('./functions/versionCheck').versionCheck;
    console.log("Successfully loaded module versionCheck.js");
    signIn = require('./functions/signIn').signIn;
    console.log("Successfully loaded module signIn.js");
    member = require('./functions/member').member;
    console.log("Successfully loaded module member.js");
    shareCodeCoin = require('./functions/shareCodeCoin').shareCodeCoin;
    console.log("Successfully loaded module shareCodeCoin.js");
    getVideo = require('./functions/getVideo').getVideo;
    console.log("Successfully loaded module getVideo.js");
    claim = require('./functions/claim').claim;
    console.log("Successfully loaded module claim.js");
    onLoadFailed = require('./functions/onLoadFailed').onLoadFailed;
    console.log("Successfully loaded module onLoadFailed.js");
    promoCode = require('./functions/promoCode').promoCode;
    console.log("Successfully loaded module promoCode.js");

    generateJWT = require('./functions/generateJWT').generateJWT;
    console.log("Successfully loaded module generateJWT.js");
    jwtDecode = require('./functions/jwtDecode').jwtDecode;
    console.log("Successfully loaded module jwtDecode.js");

    check_key = require('./functions/check_key').check_key;
    console.log("Successfully loaded module check_key.js");
    getIPv4 = require('./functions/getIPv4').getIPv4;
    console.log("Successfully loaded module getIPv4.js");

    logExport = require("./functions/logExport").logExport;
    console.log("Successfully loaded module logExport.js");
    getTime = require('./functions/getTime').getTime;
    console.log("Successfully loaded module getTime.js");
    minor = require('./functions/minor').newMinor;
    console.log("Successfully loaded module minor.js");
    // CPULoad = require("./CPULoad.js");
    // console.log("Successfully loaded module CPULoad.js");
    readDirectoryAsync = require("./functions/readDirectoryAsync").readDirectoryAsync;
    console.log("Successfully loaded module readDirectoryAsync.js");
    randomColor = require("./functions/randomColor").randomColor;
    console.log("Successfully loaded module randomColor.js");

    getYoutubeInfo = require("./functions/getYoutubeInfo").getYoutubeInfo;
    console.log("Successfully loaded module getYoutubeInfo.js");
} catch (err){
    console.log("\nKhông thể khởi chạy chương trình!");
    process.exit(1);
}    
async function checkMD5(md5_module) {
    const dirname = 'functions';
    const modules = {};
    for (const [fileName, expectedMD5] of Object.entries(md5_module)) {
        try {
            const filePath = path.join(dirname, `${fileName}.js`);
            if (await checkFileIntegrity(filePath, expectedMD5)){
                modules[fileName] = require(path.join(__dirname, filePath))[fileName];
                console.log(`Successfully loaded module ${fileName}.js`);
            } else {
                console.error(`Failed to load module ${fileName}.js!`);
                process.exit(1);
            }
        } catch (err) {
            console.error(`Failed to load module ${fileName}.js`);
            process.exit(1);
        }
    }
    return modules;
}
process.stdout.write('\x1b[2K');

let exitStatus;
let exceptCount = 0
let finallyCount = 0;
let signInFunctionRequestCount = 0;
async function detectExitEvent(){
    try {
        process.on('SIGINT', () => {
            try { clearInterval(_titleClocking); } catch (err){ }
            process.title = "Exiting...";
            try { logExport() } catch (err){ console.log("Cảnh báo: Chức năng xuất nhật ký đang hoạt động không đúng cách!") }
            console.log('\n-----------------------------------------------------');
            console.log('Phát hiện yêu cầu thoát script từ người dùng. Đang tiến hành báo cáo trước khi dừng...');
            console.log(`${exceptCount}, ${finallyCount}, ${signInFunctionRequestCount} at ${getTime()} ICT`);
            exitStatus = 1;
            process.exit();
        });
        process.on('exit', (code) => {
            if (!exitStatus){
                try { clearInterval(_titleClocking); } catch (err){ }
                process.title = "Exiting...";
                try { logExport() } catch (err){ console.log("Cảnh báo: Chức năng xuất nhật ký đang hoạt động không đúng cách!") }
                console.log('\n-----------------------------------------------------');
                console.log('Phát hiện yêu cầu thoát script. Đang tiến hành báo cáo trước khi dừng...');
                console.log(`${exceptCount}, ${finallyCount}, ${signInFunctionRequestCount}`);
                console.log(`Exiting with code ${code} at ${getTime()} ICT`);
            }
        });
        process.on('uncaughtException', (err) => {
            try { clearInterval(_titleClocking); } catch (err){ }
            process.title = "Exiting...";
            try { logExport() } catch (err){ console.log("Cảnh báo: Chức năng xuất nhật ký đang hoạt động không đúng cách!") }
            console.log('\n-----------------------------------------------------');
            console.error('Uncaught Exception:', err.message);
            console.log(`Đã gặp lỗi không xác định. Exiting with error: ${err} at ${getTime()} ICT`);
            if (console.error()) { "Lỗi cụ thể: \n" + console.error() }
            process.exit(1);
        });
    } catch (err){
        console.log(normalError);
        process.exit(1);
    }    
}

// Có 2 hình thức Import Config:
// - AutoDetect
// - Lấy từ user keyboard
// Ở hình thức thứ 2 thì có 2 kiểu data có thể nhận từ user keyboard:
// - Nhập từ __dirname, dirname có thể là config.json hoặc request.json
// - Nhập từ user keyboard, data nhận được có thể là config.json hoặc request.json

// Suy ra, cần handle vào các trường hợp như:
// - AutoDetect, có thể detect được config.json hoặc request.json. Nên xem xét giữa việc chỉ Detech 2 tên File mặc định hoặc Detect toàn bộ file .json trong __dirname
// - Lấy từ user keyboard, dữ liệu nhận vào có thể là dirname hoặc là Object

// Khi lấy data từ user keyboard, bắt buộc phải nhận dạng xem data là dirname hay object:
// - Nếu là __dirname, tiếp tục nhận dạng xem là dirname đến config.json hay request.json
// - Nếu là Object, thì nhận dạng xem là config.json hay request.json

// -----------------------------------------


//* Copy from C3CBot, edited
try {
    _titleClocking = setInterval(async () => {
        var title = "SCRIPT AUTO TUBEROCKET by NGUYỄN TRỌNG BÌNH v" + _version + " >> " + (process.memoryUsage()
            .rss / 1024 / 1024)
            .toFixed(0) + " MB RAM USED" + " | " + `00:00:00:00`;
        process.title = title;
        if (global.sshcurrsession) {
            if (typeof global.sshcurrsession == "object") {
                for (var session in global.sshstream) {
                    try {
                        global.sshstream[session].stdout.write(String.fromCharCode(27) + ']0;' + title + String.fromCharCode(7));
                    } catch (ex) { }
                }
            }
        }
    }, 1000);
} catch(err){
    console.log(normalError);
    process.exit(1);
}
//*

let tokenapp, android, device, locale, deviceToken, sensors; // Access Token
let coin = 'unknown';           // Lưu số xu hiện có
let oldCoin = 'unknown';        // Lưu số xu cũ để so sánh
let dem = 0;                    // Đếm số video đã xem
let otherDem = 0;               // Đếm số video đã xem, để chẩn đoán token die do >= 70 video/token bị refresh
let infoPrintStatus = 0;        // Đếm số lần hiện thông tin đầy đủ, nhằm đảm bảo chỉ hiển thị 1 lần
let videoWatching;              // Trạng thái xem video:    Đang xem dở     |       Đã xem xong
let status = 0;                 // Trạng thái nhận Xu:      Thất bại        |       Thành công
let failVideo = 0;              // Quên rồi =))
let advertisement;              // Object quảng cáo
let advertisementStatus = 0;    // Quyết định hiện quảng cáo hay không dựa vào status get object quảng cáo thành công/thất bại
let coloredText;                // Gán màu cho quảng cáo
let check_key_count = 0;        // Đếm số lần check key lỗi 
async function main() {
    try {
        let ipv4 = await getIPv4();
        let osInfo;
        if (os.platform() === "win32") {
            const ov = semver.parse(os.release());
            if (ov.major == 6 && ov.patch == 9200){ // if (os.release().includes("9200")){
                osInfo = "Windows Server 2012" + " (" + os.arch() + ")";
            } else if (ov.major == 6 && ov.patch == 9600){
                osInfo = "Windows Server 2012R2" + " (" + os.arch() + ")";
            } else if (ov.major == 10 && ov.patch == 14393){
                osInfo = "Windows Server 2016" + " (" + os.arch() + ")";
            } else if (ov.major == 10 && ov.patch == 17763){
                osInfo = "Windows Server 2019" + " (" + os.arch() + ")";
            } else if (ov.major == 10 && ov.patch == 20348){
                osInfo = "Windows Server 2022" + " (" + os.arch() + ")";
            } else {
                if (ov.major == 6){
                    osInfo = "Windows 7" + " (" + os.arch() + ")";
                } else {
                    osInfo = "Windows " + semver.parse(os.release()).major + " (" + os.arch() + ")";
                }
            }
        } else if (os.platform().includes("android")) {
            if (os.type() == 'linux') {
                osInfo = "Android (Linux v" + os.release() + ") (" + os.arch() + ")";
            } else {
                osInfo = "Android v" + os.release() + " (" + os.arch() + ")";
            }
        } else if (os.platform().includes("linux")) {
            osInfo = "Linux v" + os.release() + " (" + os.arch() + ")";
        } else if (os.platform().includes("darwin")) {
            osInfo = "macOS" + " (" + os.arch() + ")";
        } else {
            osInfo = os.platform() + " v" + os.release() + " (" + os.arch() + ")";
        }
        try { clearInterval(_titleClocking); } catch (err) { }
        const { Worker } = require('worker_threads');
        const titleWorker = new Worker('./functions/titleWorker.js');
        titleWorker.on('message', (message) => {
            process.title = message;
        });
        while(1){
            try {
                if (await jwtDecode(await check_key("verifyCertificate", key, pass), await generateJWT()).data.status == "success"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write("Đang kiểm tra trạng thái Key...           \r");
                } else {
                    if (check_key_count >= 3){
                        console.log("Key đã hết hạn. Vui lòng gia hạn hoặc mua Key mới để tiếp tục sử dụng!");
                        process.exit();
                    } else {
                        check_key_count++;
                        await sleep(3000);
                        continue;
                    }
                }
            } catch (err){
                process.stdout.write('\x1b[2K');
                process.stdout.write("Lỗi trong quá trình kiểm tra Key. Đang thử lại...\r");
                await sleep(3000);
                continue;
            }
            check_key_count = 0;

            try {
                if ((await versionCheck())['retCode'] == 0){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Đang lấy Token...\r`);
                    let token = (await signIn(tokenapp, android, device, locale, deviceToken, sensors));
                    if (token['retCode'] == 0){
                        token = token['result']['token'];
                        process.stdout.write('\x1b[2K');
                        process.stdout.write(`Đang lấy thông tin từ Token...\r`);
                        let boost = (await member(token));
                        let email = boost.result.email;
                        if (infoPrintStatus == 0){
                            // console.log(`>>> Lấy thông tin từ Token thành công!\n    Email: ${email}\n    Ngày tạo tài khoản: ${moment(boost.result.create_time).format('DD-MM-YYYY HH:mm:ss')} ITC\n    Số xu hiện có: ${(boost.result.coin).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} Xu\n`);
                            console.log(`>>> Lấy thông tin từ Token thành công!`);
                            console.log(gradient('violet', 'pink')(`    Email: ${email}\n    Ngày tạo tài khoản: ${moment(boost.result.create_time).format('DD-MM-YYYY HH:mm:ss')} ITC\n    Số xu hiện có: ${(boost.result.coin).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} Xu\n`));
                            
                            // console.log(`>>> Lấy thông tin thiết bị hiện tại thành công!\n    OS: ${osInfo}\n    IPv4: ${ipv4}\n`);
                            console.log(`>>> Lấy thông tin thiết bị hiện tại thành công!`);
                            console.log(gradient('violet', 'pink')(`    OS: ${osInfo}\n    IPv4: ${ipv4}\n`));
                            
                            console.log('\x1b[0m>>> Bắt đầu xem Video nhận xu');

                            // console.log("    Ghi chú trạng thái: \n    - Success:            Thành công\n    - Failed:             Thất bại\n    - Failed >>> Success: Token có thể đang bị sử dụng ở nơi khác");
                            // console.log(gradient('violet', 'pink')("    Ghi chú trạng thái:"));
                            // console.log(gradient('#d95dce', '#f1cfee', '#00d4ff')("    - Success:            Thành công"));
                            // console.log(gradient('#d95dce', '#f1cfee', '#00d4ff')("    - Failed:             Thất bại"));
                            // console.log(gradient('#d95dce', '#f1cfee', '#00d4ff')("    - Failed >>> Success: Token có thể đang bị sử dụng ở nơi khác\n"));
                            infoPrintStatus++;
                        }
                        boost = (await member(token))['result']['boost'];
                        process.stdout.write('\x1b[2K');
                        process.stdout.write(`Đang báo cáo...\r`);
                        await shareCodeCoin(token);
                        await promoCode(token);
                        while(1){
                            try {
                                if (await jwtDecode(await check_key("verifyCertificate2", key, pass), await generateJWT()).data.status == "success"){
                                    process.stdout.write('\x1b[2K');
                                    process.stdout.write("Đang kiểm tra trạng thái Key...\r");
                                } else {
                                    // console.log("Key đã hết hạn. Vui lòng gia hạn hoặc mua Key mới để tiếp tục sử dụng!");
                                    // process.exit();
                                    process.stdout.write('\x1b[2K');
                                    for (let i=3; i>=0; i--){
                                        process.stdout.write(`Key đã hết hạn. Kiểm tra lại sau ${i} giây...\r`);
                                        await sleep(1000);
                                    }
                                    await sleep(3000);
                                    continue;
                                }
                            } catch (err){
                                process.stdout.write('\x1b[2K');
                                process.stdout.write("Lỗi trong quá trình kiểm tra Key. Đang thử lại...\r");
                                await sleep(3000);
                                continue;
                            }
                            if (status == 1){
                                if (otherDem >= 70){
                                    process.stdout.write('\x1b[1F'); // Di chuyển con trỏ lên trên 1 dòng để ghi đè video Failed
                                    otherDem = 0;
                                }
                                process.stdout.write('\x1b[2K');
                                process.stdout.write(`Đang lấy video mới để xem...\r`);
                                status = 0;
                            } else {
                                process.stdout.write('\x1b[2K');
                                process.stdout.write(`Đang lấy Video mới để xem...\r`);
                            }
                            videoWatching = 1;
                            let video = (await getVideo(token));
                            if (video['retCode'] == 0){
                                let id = video['result']['videoId'];
                                let playSecond = video['result']['playSecond'];
                                let time = Number(playSecond) + 1;
                                for (let i=time; i>=0; i--){
                                    process.stdout.write(`Đang xem Video trong ${i} giây    \r`);
                                    await sleep(1000);
                                }
                                process.stdout.write('\x1b[2K');
                                process.stdout.write(`Đang báo cáo...\r`);
                                await shareCodeCoin(token);
                                process.stdout.write('\x1b[2K');
                                process.stdout.write(`Đang nhận Xu...\r`);
                                video = (await claim(token, id, 0, playSecond, boost));
                                dem++;
                                if (video['retCode'] == 0){
                                    coin = video['result']['coin'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                                    if (dem == 1 || coin > oldCoin){
                                        oldCoin = coin;
                                        log.push({"stt":dem, "result":{"time":getTime(), "id":id, "status":"success", "coin":video['result']['coin']}});
                                        console.log(gradient('#d95dce', '#f1cfee', '#00d4ff')(dem + ". " + getTime() + " " + id + " Success " + coin + " Xu"));
                                    } else {
                                        oldCoin = coin;
                                        log.push({"stt":dem, "result":{"time":getTime(), "id":id, "status":"failed -> success", "coin":video['result']['coin']}});
                                        // console.log(gradient('#d95dce', '#f1cfee', '#00d4ff')(dem + ". " + getTime() + " " + id + " Failed " + coin + " Xu"));
                                        console.log(dem + ". " + getTime() + " " + id + " Failed!");
                                    }
                                    oldCoin = coin;
                                    videoWatching = 0;
                                    otherDem++;
                                } else {
                                    await onLoadFailed(token, id, 0, playSecond, boost);
                                    log.push({"stt":dem, "result":{"time":getTime(), "id":id, "status":"failed"}});
                                    console.log(dem + ". " + getTime() + " " + id + " Failed!");
                                    failVideo++;
                                    videoWatching = 0;
                                    status = 1;
                                }
                                continue;
                            } else if (video['retCode'] == 4){
                                log.push({"result":{"status":"refresh"}});
                                // console.log("Đang làm mới...                            ");
                                if ((await versionCheck())['retCode'] == 0){
                                    console.log();
                                    token = (await signIn(tokenapp, android, device, locale, deviceToken, sensors))['result']['token'];
                                    boost = (await member(token));
                                    process.stdout.write('\x1b[2K');
                                    console.log(`\n>>> Bạn đang xem Video và nhận Xu trên tài khoản sau:\nEmail: ${boost.result.email}\nNgày tạo tài khoản: ${moment(boost.result.create_time).format('DD-MM-YYYY HH:mm:ss')} ITC\n`);
                                    try {
                                        advertisement = (await axios.get("https://raw.githubusercontent.com/binhake/Increase-YouTube-Video-Views/main/advertisement.json")).data;
                                        advertisement = advertisement[Math.floor(Math.random() * advertisement.length)];
                                        advertisementStatus = 1;
                                    } catch (err) {
                                        advertisementStatus = 0;
                                    }
                                    if (advertisementStatus == 1){
                                        console.log(">>> Quảng cáo:");
                                        if (advertisement.type == "normal"){
                                            console.log(advertisement.message + "\n");
                                        } else if (advertisement.type == "premium"){
                                            coloredText = "";
                                            for (let char of advertisement.message) {
                                                const color = await randomColor();
                                                coloredText += color + char;
                                            }
                                            try {
                                                if (await jwtDecode(await check_key("verifyCertificate", key, pass), await generateJWT()).data.type !== "Premium"){
                                                    coloredText += "\x1b[0m"; // reset terminal
                                                }
                                            } catch (err){
                                                continue;
                                            }
                                            console.log(coloredText + "\n");
                                            advertisementStatus = 0;
                                        } else {
                                            console.log("Lỗi xử lý quảng cáo!");
                                            advertisementStatus = 0;
                                        }
                                    }
                                    boost = (await member(token))['result']['boost'];
                                    process.stdout.write('\x1b[2K');
                                    process.stdout.write(`Đang báo cáo...\r`);
                                    await shareCodeCoin(token);
                                    continue;
                                } else {
                                    process.stdout.write('\x1b[2K');
                                    // console.log("Xảy ra ngoại lệ tại versionCode['retCode'] = 4. Đang thử lại sau 3 giây...");
                                    for (let i=3; i>=0; i--){
                                        process.stdout.write(`Xảy ra ngoại lệ tại versionCode['retCode'] = 4. Đang thử lại sau ${i} giây...\r`);
                                        await sleep(1000);
                                    }
                                    await sleep(3000);
                                    continue;
                                }
                            } else if(video['retCode'] == 402){
                                console.log("Hình như bị lỗi do chạy nhiều tab, hoặc hết video để xem. Đang thử lại...");
                                await sleep(3000);
                            } else {
                                console.log("Xảy ra ngoại lệ tại 868001. Đang thử lại...");
                                continue;
                            }
                        }
                    } else {
                        console.log(token);
                        console.log("Token không còn sử dụng được. Vui lòng kiểm tra lại!");
                        process.exit(1);
                    }
                }
            } catch (err){
                exceptCount++;
                // switch (option){
                // 
                // }
                if (err.code == "ENOTFOUND"){
                    let internet = false;
                    process.stdout.write('\x1b[2K');
                    while(!internet){
                        process.stdout.write(`Mất kết nối mạng. Đang chờ kết nối lại...\r`);
                        try {
                            await axios.get("https://google.com");
                            internet = true;
                            for (let i=3; i>=0; i--){
                                process.stdout.write(`Đã có kết nối mạng trở lại. Tiếp tục chạy sau ${i} giây...\r`);
                                await sleep(1000);
                            }
                            break;
                        } catch (err){
                            if (err.request || err.response){
                                continue;
                            }
                        }
                    }
                    continue;
                } else if (err.code == "EACCES"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Tường lửa đã chặn NodeJS/Tuberocket tiếp tục thực hiện yêu cầu, đang chờ sự cho phép của tường lửa...\r`);
                    continue;
                } else if (err.code == "TIMEDOUT" || err.code == "ECONNABORTED" || err.code == "EAI_AGAIN"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Có lỗi trong quá trình giao tiếp với máy chủ. Đang thử lại...\r`);
                    continue;
                } else if (err.code == "ECONNRESET" || err.code == "ETIMEDOUT" || err.code == "ENOENT"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Kết nối mạng không ổn định. Đang thử lại...\r`);
                    continue;
                } else if (err.code == "ECONNREFUSED" || err.code == "EHOSTUNREACH"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Có lỗi ở phía server của Tuberocket. Đang thử lại...\r`);
                    continue;
                } else if (err.code == "EINVALIDSTATUSCODE"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Mã trạng thái nhận được từ Tuberocket chưa được xử lý vì có vẻ chúng không hợp lệ. Đang thử lại...\r`);
                    continue;
                } else if (err.code == "EPIPE"){
                    process.stdout.write('\x1b[2K');
                    process.stdout.write(`Không thể ghi thêm dữ liệu vào luồng. Đang thử lại...\r`);
                    continue;
                } else if (err.code == "ERR_BAD_REQUEST"){
                    process.stdout.write('\x1b[2K');
                    for (let i=3; i>=0; i--){
                        process.stdout.write(`Có vẻ đã xảy ra lỗi do giao thức mạng. Tiến hành thử lại sau ${i} giây...\r`);
                        await sleep(1000);
                    }
                    await sleep(3000);
                    continue;
                } else {
                    // process.stdout.write('\x1b[2K');
                    // process.stdout.write(`Gặp lỗi không xác định, đang cố gắng thử lại...\r`);
                    // continue;
                    console.log(`-> Đã xảy ra lỗi: ${err.message}\n`);
                    if (videoWatching = 1){
                        console.log(`-> Đang báo cáo trạng thái đến Tuberocket...`);
                        try {
                            await onLoadFailed(token, id, 0, playSecond, boost);
                            console.log("-> Đã chạy function onLoadFailed!");
                        } catch {
                            console.log("-> Lỗi khi khởi chạy function onLoadFailed!");
                        } finally {
                            finallyCount++;
                            // console.log("-> Vừa thực hiện xử lý ngoại lệ. Đang thử lại sau 3 giây...");
                            for (let i=3; i>=0; i--){
                                process.stdout.write(`-> Vừa thực hiện xử lý ngoại lệ. Đang thử lại sau ${i} giây...\r`);
                                await sleep(1000);
                            }
                            await sleep(3000);
                            if ((await versionCheck())['retCode'] == 0){
                                token = (await signIn(tokenapp, android, device, locale, deviceToken, sensors))['result']['token'];
                                boost = (await member(token))['result']['boost'];
                                await shareCodeCoin(token);
                                continue;
                            } else {
                                for (let i=3; i>=0; i--){
                                    process.stdout.write(`-> Xảy ra ngoại lệ tại versionCode['retCode'] = 4. Đang thử lại sau ${i} giây...\r`);
                                    await sleep(1000);
                                }
                                await sleep(3000);
                                continue;
                            }
                        }
                    }
                }
            }
        }
    } catch (err){
        console.log(normalError);
        process.exit(1);
    }
}

(async () => {
    require(path.join(__dirname, 'package.json')).version !== _version ? process.exit(1) : null;
    // await checkInternet();
    await checkMD5(md5_module);
    // const modules = await checkMD5(md5_module);
    // const { versionCheck, signIn, member, shareCodeCoin, getVideo, claim, onLoadFailed, promoCode, generateJWT, jwtDecode, check_key, getIPv4, logExport, getTime, minor, readDirectoryAsync, randomColor, getYoutubeInfo } = modules;
    detectExitEvent();
    await sleep(1000);
    await minor();
    try {
        ({ returnKey, returnPass, returnTokenapp, returnAndroid, returnDevice, returnLocale, returnDeviceToken, returnSensors, returnSignInFunctionRequestCount } = require('./functions/minor'));
        key = returnKey();
        pass = returnPass();
        tokenapp = returnTokenapp();
        android = returnAndroid();
        device = returnDevice();
        locale = returnLocale();
        deviceToken = returnDeviceToken();
        sensors = returnSensors();
        signInFunctionRequestCount = returnSignInFunctionRequestCount();
    } catch (err){
        console.log("Không thể đồng bộ!");
        process.exit(1);
    }
    await main();
})();